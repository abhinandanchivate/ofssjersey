package com.ofss.ecommerce.repository;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.jvnet.hk2.annotations.Contract;

import com.ofss.ecommerce.dto.User;
import com.ofss.ecommerce.exception.NoDataFoundException;
@Contract
public interface UserRepository {
	public User addUser( User user) throws SQLException;
	public User getUserById(String id) throws NoDataFoundException;
	public List<User> getAllUsers() throws NoDataFoundException;
	public Optional<List<User>> getAUsersByFirstName(String firstName);
	
	public String deleteByUserId(String userId);
	public User updateByUserId(String userId,User user);
}