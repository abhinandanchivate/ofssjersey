package com.ofss.ecommerce.service;

import java.util.List;
import java.util.Optional;

import org.jvnet.hk2.annotations.Service;

import com.ofss.ecommerce.dto.Product;
import com.ofss.ecommerce.repository.ProductRepository;
import com.ofss.ecommerce.repository.ProductRepositoryImpl;
import com.ofss.ecommerce.repository.UserRepository;
import com.ofss.ecommerce.repository.UserRepositoryImpl;
@Service
public class ProductServiceImpl implements ProductService {

	private ProductRepository productRepository = ProductRepositoryImpl.getInstance();

	@Override
	public Product addProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Product> getProductById(String id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public Optional<List<Product>> getAllProduct() {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public Optional<List<Product>> getProductsByFirstName(String firstName) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public String deleteByProductId(String productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product updateByProductId(String productId, Product product) {
		// TODO Auto-generated method stub
		return null;
	}

}
