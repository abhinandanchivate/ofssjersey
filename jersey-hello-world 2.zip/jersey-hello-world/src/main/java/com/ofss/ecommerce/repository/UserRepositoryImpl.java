package com.ofss.ecommerce.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.jvnet.hk2.annotations.Service;

import com.ofss.ecommerce.dto.User;
import com.ofss.ecommerce.exception.NoDataFoundException;
import com.ofss.ecommerce.utils.DbUtils;

@Service
public class UserRepositoryImpl implements UserRepository {

//	private UserRepositoryImpl() {
//		// TODO Auto-generated constructor stub
//	}
//
//	private static UserRepositoryImpl userRepositoryImpl = null;
//
//	public static UserRepositoryImpl getInstance() {
//		// TODO Auto-generated method stub
//		synchronized (UserRepositoryImpl.class) {
//			if (userRepositoryImpl == null) {
//				userRepositoryImpl = new UserRepositoryImpl();
//				return userRepositoryImpl;
//			}
//		}
//
//		return userRepositoryImpl;
//
//	}
//
	@Override
	public User addUser(User user) throws SQLException {
		Connection connection = DbUtils.getConnection();
		String insertStatement = "insert into users (userId,firstName,lastName,address,phoneNumber,password)"
				+ "values(?,?,?,?,?,?)";
		PreparedStatement preparedStatement = connection.prepareStatement(insertStatement);
		preparedStatement.setInt(1, user.getUserId());
		preparedStatement.setString(2, user.getFirstName());
		preparedStatement.setString(3, user.getLastName());
		preparedStatement.setString(4, user.getAddress());
		preparedStatement.setString(5, user.getPhoneNumber());
		preparedStatement.setString(6, user.getPassword());

		int result = preparedStatement.executeUpdate();

		if (result > 0) {
			return user;
		}
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserById(String id) throws NoDataFoundException {
		// TODO Auto-generated method stub
		User user = null; // Initialize user to null

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			// Get a connection to the database
			connection = DbUtils.getConnection();

			// Prepare the SQL query to select the user by ID
			String selectStatement = "SELECT userId, firstName, lastName, address, phoneNumber, password FROM users WHERE userId = ?";
			preparedStatement = connection.prepareStatement(selectStatement);

			// Set the parameter for the prepared statement
			preparedStatement.setString(1, id);

			// Execute the query
			resultSet = preparedStatement.executeQuery();

			// Check if a user was found
			if (resultSet.next()) {
				user = new User(); // Create a new User object
				user.setUserId(resultSet.getInt("userId"));
				user.setFirstName(resultSet.getString("firstName"));
				user.setLastName(resultSet.getString("lastName"));
				user.setAddress(resultSet.getString("address"));
				user.setPhoneNumber(resultSet.getString("phoneNumber"));
				user.setPassword(resultSet.getString("password")); // Be cautious with exposing passwords!
			//	return Optional.of(user);
			}
		} catch (SQLException e) {
			e.printStackTrace(); // Log the exception (consider using a logger)
		} finally {
			// Clean up resources
			try {
				if (resultSet != null)
					resultSet.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace(); // Log any exceptions during cleanup
			}
		}
		return Optional.ofNullable(user).orElseThrow(()->new NoDataFoundException("exception"));

	}

	@Override
	public List<User> getAllUsers() throws NoDataFoundException {
		// TODO Auto-generated method stub
		List<User> users = new ArrayList();

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			Connection connection = DbUtils.getConnection();
			String selectStatement = "SELECT userId, firstName, lastName, address, phoneNumber, password FROM users";
			preparedStatement = connection.prepareStatement(selectStatement);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				User user = new User();
				user.setUserId(resultSet.getInt("userId"));
				user.setFirstName(resultSet.getString("firstName"));
				user.setLastName(resultSet.getString("lastName"));
				user.setAddress(resultSet.getString("address"));
				user.setPhoneNumber(resultSet.getString("phoneNumber"));
				user.setPassword(resultSet.getString("password")); // Be cautious with exposing passwords!
				users.add(user);
			}

		} catch (SQLException e) {
			e.printStackTrace(); // Consider logging the exception instead

		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (preparedStatement != null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace(); // Consider logging the exception instead
			}
		}
		//users.add(new User("abhi", "chivate", "pune", "1234567890", "abhi1234", 1));
		return Optional.ofNullable(users).orElseThrow(()->new NoDataFoundException("thre is no data"));
	}

	@Override
	public Optional<List<User>> getAUsersByFirstName(String firstName) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public String deleteByUserId(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User updateByUserId(String userId, User user) {
		// TODO Auto-generated method stub
		return null;
	}

}
