package com.ofss.ecommerce.utils;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbUtils {
	private static Properties loadProperties() {
		try(InputStream inputStream = DbUtils.class.getClassLoader().
				getResourceAsStream("application.properties"))
		{
		Properties properties = new Properties();
		properties.load(inputStream);
		System.out.println(properties);
		return properties;
		}
		catch(IOException e) {
			return null;
		}
	}
		
	public static Connection getConnection() throws SQLException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Properties properties = loadProperties();
		Connection connection = DriverManager.getConnection(properties.getProperty("jdbc.url")
				,"root"
				,"your_password");
		
		return connection;
		
	}
	
	public void closeConnection(Connection connetion) {
		try {
			connetion.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		Properties properties = loadProperties();
		System.out.println(properties);
	}
}
