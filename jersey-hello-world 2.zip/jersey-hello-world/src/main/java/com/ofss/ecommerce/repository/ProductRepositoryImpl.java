package com.ofss.ecommerce.repository;

import java.util.List;
import java.util.Optional;

import com.ofss.ecommerce.dto.Product;

public class ProductRepositoryImpl implements ProductRepository {
	private static ProductRepositoryImpl productRepositoryImpl = null;

	public static ProductRepositoryImpl getInstance() {
		// TODO Auto-generated method stub
		synchronized (ProductRepositoryImpl.class) {
			if (productRepositoryImpl == null) {
				productRepositoryImpl = new ProductRepositoryImpl();
				return productRepositoryImpl;
			}
		}

		return productRepositoryImpl;

	}
	@Override
	public Product addProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Product> getProductById(String id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public Optional<List<Product>> getAllProduct() {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public Optional<List<Product>> getProductsByFirstName(String firstName) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public String deleteByProductId(String productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product updateByProductId(String productId, Product product) {
		// TODO Auto-generated method stub
		return null;
	}

}
