package com.ofss.ecommerce.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.jvnet.hk2.annotations.Service;

import com.ofss.ecommerce.dto.User;
import com.ofss.ecommerce.exception.NoDataFoundException;
import com.ofss.ecommerce.repository.UserRepository;
import com.ofss.ecommerce.repository.UserRepositoryImpl;

import jakarta.inject.Inject;
@Service
public class UserServiceImpl implements UserService {
	@Inject
	private UserRepository userRepository;
	//private static UserServiceImpl userServiceImpl = null;
	
//	private UserRepository userRepository = UserRepositoryImpl.getInstance();
//
//	public static UserServiceImpl getInstance() {
//		// TODO Auto-generated method stub
//		synchronized (UserServiceImpl.class) {
//			if (userServiceImpl == null) {
//				userServiceImpl = new UserServiceImpl();
//				return userServiceImpl;
//			}
//		}
//
//		return userServiceImpl;
//
//	}
	
	@Override
	public User addUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		return userRepository.addUser(user);
	}

	@Override
	public User getUserById(String id) throws NoDataFoundException {
		// TODO Auto-generated method stub
		return userRepository.getUserById(id);
	}

	@Override
	public List<User> getAllUsers() throws NoDataFoundException {
		// TODO Auto-generated method stub
		return userRepository.getAllUsers();
	}

	@Override
	public Optional<List<User>> getAUsersByFirstName(String firstName) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public String deleteByUserId(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User updateByUserId(String userId, User user) {
		// TODO Auto-generated method stub
		return null;
	}

}
