package com.ofss.ecommerce.service;

import java.util.List;
import java.util.Optional;

import org.jvnet.hk2.annotations.Contract;

import com.ofss.ecommerce.dto.Product;
@Contract
public interface ProductService {
	public Product addProduct();
	public Optional<Product> getProductById(String id);
	public Optional<List<Product>> getAllProduct();
	public Optional<List<Product>> getProductsByFirstName(String firstName);
	
	public String deleteByProductId(String productId);
	public Product updateByProductId(String productId,Product product);
}
