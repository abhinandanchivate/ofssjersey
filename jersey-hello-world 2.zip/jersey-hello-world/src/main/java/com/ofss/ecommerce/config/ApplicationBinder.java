package com.ofss.ecommerce.config;

import org.glassfish.hk2.utilities.binding.AbstractBinder;

import com.ofss.ecommerce.service.UserService;
import com.ofss.ecommerce.service.UserServiceImpl;

public class ApplicationBinder extends AbstractBinder {
    @Override
    protected void configure() {
        bind(UserServiceImpl.class).to(UserService.class);
    }
}
