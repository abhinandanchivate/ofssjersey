package com.ofss.ecommerce.repository;
import java.util.List;
import java.util.Optional;
import com.ofss.ecommerce.dto.Product;
public interface ProductRepository {
	public Product addProduct();
	public Optional<Product> getProductById(String id);
	public Optional<List<Product>> getAllProduct();
	public Optional<List<Product>> getProductsByFirstName(String firstName);
	
	public String deleteByProductId(String productId);
	public Product updateByProductId(String productId,Product product);
	
}