package com.ofss.ecommerce.dto;

import java.time.LocalDate;

import lombok.*;
import lombok.ToString.Exclude;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude={"productPrice" ,"expiryDate"})
public class Product {
	private String productId;
	private String productName;
	private float  productPrice;
	private LocalDate manufacturingDate;
	private LocalDate expiryDate;
	
}
