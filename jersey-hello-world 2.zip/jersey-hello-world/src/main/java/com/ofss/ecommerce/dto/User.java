package com.ofss.ecommerce.dto;
import lombok.*;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
	private String firstName;
	private String lastName;
	private String address;
	@Override
	public String toString() {
		return "User [firstName=" + firstName + ", lastName=" + lastName + ", address=" + address + ", phoneNumber="
				+ phoneNumber + ", password=" + password + ", userId=" + userId + "]";
	}
	private String phoneNumber;
	private String password;
	private int userId;
}
