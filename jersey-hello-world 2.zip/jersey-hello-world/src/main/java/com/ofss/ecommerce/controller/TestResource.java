package com.ofss.ecommerce.controller;

import java.util.List;

import com.ofss.ecommerce.dto.User;
import com.ofss.ecommerce.exception.NoDataFoundException;
import com.ofss.ecommerce.service.UserService;
import com.ofss.ecommerce.service.UserServiceImpl;

import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/api/v1/test")
public class TestResource {
	
	@Inject
	private UserService userService;
	
	@Path("/name")
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getName() {
		return "abhi";
	}

@Path("/{name}")
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getUserDetailsByName(@PathParam("name") String name) {
		return name;
	}

	@Path("/all")
		@GET
		//@Produces(MediaType.APPLICATION_JSON)
			public String getAllDetails() {
		try {
			return userService.getAllUsers().toString();
		} catch (NoDataFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


}













